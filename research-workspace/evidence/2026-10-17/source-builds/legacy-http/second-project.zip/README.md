# Research evidence bundle

Project ID: 11885522d52545cb942a680928de4934

Descriptive, provisional evidence only. Integrity and lineage checks do not establish scientific validity, independent reproduction, or authenticity.

project.json records the study question and declared success criterion.
runs.json includes every supplied run, including failures and incomplete work.
comparison.json reports descriptive metrics and explicit evidence gaps.
METHODS.md describes the reviewed conditions and a bounded rerun procedure.
Selected input, recipe, and available result bytes live under runs/<run-id>/.

checksums.json lists the exact SHA-256 and size of every other archive member.
It excludes itself to avoid a recursive checksum. Record the whole archive's
SHA-256 separately in a trusted system to detect wholesale replacement.
There is no signature, external attestation, or automated publication.

RO-Crate-style JSON-LD describes the files. No formal RO-Crate profile
certification, source license grant, or publication date is asserted.
Do not execute bundled recipes until independently reviewed.
