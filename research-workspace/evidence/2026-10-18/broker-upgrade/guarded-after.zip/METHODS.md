# Methods and limitations

This version supports public or synthetic CSV data with columns group,value.
The baseline retains all rows. The alternative removes one smallest and one
largest value from each group with at least five rows. Each condition reports
the retained count and arithmetic mean overall and per group. These are
descriptive summaries, not significance tests or scientific acceptance.

For each run, use its own exact input.csv and recipe.py or recipe.R. Inspect
the recipe's entry point and run condition before rerunning. Recreate the
recorded immutable environment through Outfitter with explicit CPU, memory,
time and output limits, network disabled, and reviewed read-only input.
Compare independently calculated expected values against result.json.
The export does not download images, execute code, rerun jobs or certify that
an image remains obtainable. It does not include credentials or the runner.

A queued, failed, cancelled or interrupted run may have no result. Inspect
comparison.json gaps, run errors, cleanup_verified and compute liabilities.
Charged CPU seconds are conservative estimated upper bounds, not a metered
measurement. Not-admitted work records zero charge; unknown accounting uses
null amounts with unresolved liability, never an invented zero or refund.
A valid bundle can contain unresolved cleanup or execution.

Input and recipe hashes bind declared lineage to exact bytes. Canonical JSON
manifests are hashed, and result JSON must match the declared run metrics.
These checks establish internal consistency, not authenticity or validity.
Membership, sessions, keys, raw logs and local host paths are excluded from
metadata. The exporting operator remains responsible for the selected data
and recipe content, its classification, and permission to share it.
